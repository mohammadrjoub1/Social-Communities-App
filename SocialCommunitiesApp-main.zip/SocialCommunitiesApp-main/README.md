# SocialCommunitiesApp
SocialCommunitiesApp

#Demo
https://odi003.herokuapp.com
