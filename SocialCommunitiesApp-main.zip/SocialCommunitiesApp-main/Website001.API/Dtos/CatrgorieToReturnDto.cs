using System;

namespace Website001.API.Dtos{
    public class CatrgorieToReturnDto{
        public int id{set;get;}
        public string title{set;get;}
        public string about{set;get;}
        public DateTime date{set;get;}
        public string imageUrl{set;get;}
        public string coverUrl{set;get;}
        
    }
}