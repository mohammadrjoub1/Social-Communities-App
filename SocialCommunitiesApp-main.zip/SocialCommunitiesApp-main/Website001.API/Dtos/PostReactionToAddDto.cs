
namespace Website001.API.Dtos{
    public class PostReactionToAddDto{
        public int postId{set;get;} 
        public int reactionId{set;get;} 
        
    }
}