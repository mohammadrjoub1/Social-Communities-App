namespace Website001.API.Dtos{
    public class PostReactionByNameToAddDto{
        public int postId{set;get;} 
        public string reactionName{set;get;} 
        
    }
}