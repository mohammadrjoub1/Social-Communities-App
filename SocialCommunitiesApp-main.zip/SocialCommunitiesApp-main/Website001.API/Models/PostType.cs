using System.ComponentModel.DataAnnotations;

namespace Website001.API.Models{
    public class PostType{
        public int id{set;get;}
        public string title{set;get;}
    }
}