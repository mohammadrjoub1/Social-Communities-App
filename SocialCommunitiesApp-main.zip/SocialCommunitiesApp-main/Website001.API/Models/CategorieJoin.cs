namespace Website001.API.Models{

    public class CategorieJoin{
        public int id{set;get;}
        public int userId{set;get;}
        public int categorieId{set;get;}

    }
}