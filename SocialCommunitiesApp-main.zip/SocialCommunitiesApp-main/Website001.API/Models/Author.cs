namespace Website001.API.Models{
    public class Author{
        public int id{set;get;}
        public int userId{set;get;}
        public User user{set;get;}
    }
}