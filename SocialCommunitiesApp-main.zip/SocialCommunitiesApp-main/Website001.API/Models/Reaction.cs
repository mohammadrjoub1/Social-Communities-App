namespace Website001.API.Models{
    public class Reaction{
        public int id{set;get;}
        public string name{set;get;}


    }
}