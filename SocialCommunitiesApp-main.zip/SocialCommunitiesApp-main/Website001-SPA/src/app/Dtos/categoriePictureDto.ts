export interface categoriePictureDto {
    file:File;
    userId:number;
    categorieId:number;
}