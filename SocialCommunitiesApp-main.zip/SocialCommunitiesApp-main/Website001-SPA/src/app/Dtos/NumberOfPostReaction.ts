export interface NumberOfPostReaction{
    postId:number;
    reactionId:number;
}