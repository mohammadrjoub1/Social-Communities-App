export interface CategorieToAddDto{
    title:string;
    about:string;
    date:any;
    image:File;
    cover:File;
    userId:number;
  
 
}