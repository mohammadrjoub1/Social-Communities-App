export interface profilePictureDto {
    file:File;
    userId:number;
}