export interface CategorieJoiningDto{
    userId:number;
    categorieId:number;
}