export interface PostToAddDto{
    title:string;
    content:string;
    categorieId:number;
    postTypeId:number;
    image:File;

}