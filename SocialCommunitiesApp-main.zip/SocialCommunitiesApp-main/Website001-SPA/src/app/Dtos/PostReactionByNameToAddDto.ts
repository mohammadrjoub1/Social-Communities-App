export interface PostReactionByNameToAddDto{
    postId:number;
    reactionName:string;
}