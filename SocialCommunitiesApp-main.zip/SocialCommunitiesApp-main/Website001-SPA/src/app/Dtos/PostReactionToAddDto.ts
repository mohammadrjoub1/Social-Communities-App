export interface PostReactionToAddDto{
    postId:number;
    reactionId:number;
}