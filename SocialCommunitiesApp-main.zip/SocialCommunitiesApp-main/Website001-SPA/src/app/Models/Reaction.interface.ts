export interface Reaction{
    id:number;
    name:string;
}