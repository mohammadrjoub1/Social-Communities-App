import { User } from "./Uesr.interface";

export interface Author{
    id:number;
    userId:number;
    User:User;
    user:User;
}
