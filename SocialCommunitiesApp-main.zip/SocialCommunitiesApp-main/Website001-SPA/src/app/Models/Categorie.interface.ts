export interface Categorie{
    id:number;
    title:string;
    about:string;
    date:Date;
    userId:number;
    coverUrl:string;
    imageUrl:string;
}